import { Component } from "react";

export default class App extends Component{
  render(){
    return <div> 
    <Header/>
    <div className="container-fluid">
      <main className="tm-main">
        <Routes>
          <Route path="/" element={<Home/>}/>
          <Route path="/add_category" element={<Add_Category/>}/>
          <Route path="/add_brand" element={<Add_Brand/>}/>
          <Route path="/add_product" element={<Add_Product/>}/>
        </Routes>
      </main>
    </div>
    </div>
}
  }
